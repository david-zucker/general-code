sink('pca-05jan25.txt')

#body measurement data
fat = read.table("fatdat.txt")
fat2 = fat[,10:19]
names(fat2) = c('neck','chest','abdo','hip','thigh','knee','ankle','biceps','forearm','wrist')
pc.fat = princomp(fat2,cor=F)
smry = summary(pc.fat)
print('Body Fat Data')
print(smry)
print(loadings(pc.fat, digits=3))
#
pc.loadmat = pc.fat$loadings
print(round(matrix(pc.loadmat,ncol(fat2),ncol(fat2)),digits=3))
sdvec = smry[[1]]
varvec = sdvec^2
print(round(varvec,digits=4))
lammat = diag(varvec)
Gmat = lammat %*% t(pc.loadmat^2) 
print(round(Gmat,digits=3))
Gnrm = Gmat / t(replicate(nrow(Gmat), colSums(Gmat)))
print(round(Gnrm,digits=3))

#pizza data
pizza = read.csv("pizza.csv", header = TRUE, sep = ",")
pizdat = pizza[,3:9]
pc.piz = princomp(pizdat,cor=T)
smry = summary(pc.piz)
print('Pizza Data')
print(smry)
print(loadings(pc.fat, digits=3))
#
pc.loadmat = pc.piz$loadings
print(round(matrix(pc.loadmat,ncol(pizdat),ncol(pizdat)),digits=3))
sdvec = smry[[1]]
varvec = sdvec^2
print(round(varvec,digits=4))
lammat = diag(varvec)
Gmat = lammat %*% t(pc.loadmat^2) 
print(round(Gmat,digits=3))

my.scree = function(pca.obj,name) {
  smry = summary(pca.obj)
  sdvec = smry[[1]]
  nf = length(sdvec)
  varvec = sdvec^2
  pctxpl = varvec/sum(varvec)
  plot(c(1:nf),pctxpl)
  title(name)
}  

my.scree(pc.fat,'FatDat')  
my.scree(pc.piz,'Pizza')  

sink()

