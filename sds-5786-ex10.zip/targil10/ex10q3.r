library(coin)

# FUNCTION TO TAKE A SET OF DATA AND DO A PERMUTATION TEST
dzperm.test = function(x,d) {
  #x is the data in the pooled sample
  #d=0 for control and d=1 for treatment
  n = length(x)
  n1 = sum(d)
  n0 = n-n1
  #here we compute the test statistic for the original data
  m1 = mean(x[d==1])
  m0 = mean(x[d==0])
  del.obs = m1-m0
  #here we produce the list of all 924 possible allocations using the R function combn
  cmb = combn(n,n1)
  cmb = t(cmb)
  ncmb = nrow(cmb)
  seqq = c(1:n)
  #here we compute the value of the test statistic for each of the 924 allocations
  DELvec = NULL
  for (c in 1:ncmb) {
    ixt = cmb[c,]
    ixc = seqq[!(seqq %in% ixt)]
    xb1 = mean(x[ixt])
    xb0 = mean(x[ixc])
    DELvec = c(DELvec,xb1-xb0)
  }
  #here we compute the p-values
  p.right = sum(DELvec >= del.obs)/ncmb
  p.left = sum(DELvec <= del.obs)/ncmb
  p.two.sided = sum(abs(DELvec) >= abs(del.obs))/ncmb
  ans = list(n0,n1,m1,m0,del.obs,p.right,p.left,p.two.sided)
  names(ans) = c("n0","n1","m1","m0","del.obs","p.right",
    "p.left","p.two.sided")
  return(ans)
 }

## MAIN PROGRAM ## 
 
#READ DATA 
x0 = c(0.39, 0.51,-0.58, 0.48, 0.01, 0.80)
x1 = c(2.30, 1.04, 2.10, 0.65, -0.37, 1.95)
n0 = length(x0)
n1 = length(x1)
x = c(x0,x1)
d = c(rep(0,n0),rep(1,n1))
d1 = factor(d)
 
#PART A: PERMUTATION TEST ON OBSERVED DATA  
perm.ans = dzperm.test(x,d)
print(noquote('Permutation test results'))
print(perm.ans)

#PART B: TWO-SAMPLE T-TEST
#In the output, Welch means the test allowing for unequal variances in the two groups
d1 = factor(d1)
print(noquote('Two-sample t-test results'))
print(t.test(x~d1, alternative=c("greater"), var.equal=T))
print(t.test(x~d1, alternative=c("greater"), var.equal=F))
print(t.test(x~d1, alternative=c("less"), var.equal=T))
print(t.test(x~d1, alternative=c("less"), var.equal=F))
print(t.test(x~d1, alternative=c("two.sided"), var.equal=F))

#PART C: Z TEST
print(noquote('Z test results'))
var.lump = var(x)
sfac = 1/n0 + 1/n1
z = (mean(x1)-mean(x0))/sqrt(sfac*var.lump)  
p.right = 1-pnorm(z,0,1)
p.left = pnorm(z,0,1)
p.two.sided = 2*min(p.right,p.left)
z.ans = cbind(z,p.right,p.left,p.two.sided)
print(z.ans)

#PART D: COMPARISON WITH oneway_test  
print(oneway_test(x~d1,distribution="exact",alternative="greater"))
print(oneway_test(x~d1,distribution="exact",alternative="less"))
print(oneway_test(x~d1,distribution="exact",alternative="two.sided"))
print(oneway_test(x~d1,distribution="asymptotic",alternative="greater"))
print(oneway_test(x~d1,distribution="asymptotic",alternative="less"))
print(oneway_test(x~d1,distribution="asymptotic",alternative="two.sided"))


