#PROGRAM TO COMPUTE MAXIMUM LIKELIHOOD ESTIMATES FOR THE WEIBULL DISTRIBUTION
#AND TEST HYPOTHESES ABOUT THE PARAMETERS

set.seed(5074283)
cat('\n')

#READ DATA
indat = read.table("ex9dat1.txt")
z = indat[,1]
n = length(z)

#WEIBULL CDF
wbcdf = function(theta,xv) {
  th1 = theta[1]
  th2 = theta[2]
  eth1 = exp(th1)
  eth2 = exp(th2)
  cdfval= 1 - exp(-(eth1*xv)^eth2)
  return(cdfval)
}  

#INVERSE WEIBULL CDF
#WEIBULL CDF
wbcdf_inv = function(theta,uu) {
  th1 = theta[1]
  th2 = theta[2]
  eth2 = exp(th2)
  invcdf = exp(log(-log(1-uu))/eth2 - th1)
  return(invcdf)
}  

#GRADIENT OF WEIBULL CDF
wbcdfgrd = function(theta,x) {
  th1 = theta[1]
  th2 = theta[2]
  eth1 = exp(th1)
  eth2 = exp(th2)
  expexp = eth1^eth2
  expexpxx = (eth1*x)^eth2
  srv = exp(-expexpxx)
  G1 = srv*eth2*expexpxx
  G2 = srv*eth2*expexpxx*(log(x)+th1)
  return(c(G1,G2))
}  

#WEIBULL DENSITY
wbdens = function(theta,x) {
  th1 = theta[1]
  th2 = theta[2]
  eth1 = exp(th1)
  eth2 = exp(th2)
  expexpxx1 = (eth1*x)^(eth2-1)
  expexpxx2 = (eth1*x)^eth2
  dens = eth1*eth2*expexpxx1*exp(-expexpxx2)
  return(dens)
}  
  
#LOG-LIKELIHOOD FUNCTION
llfun = function(theta,x) {
  dens = wbdens(theta,x)
  llval = sum(log(dens))
  return(llval)
}

#GRADIENT OF LOG-LIKELIHOOD FUNCTION
llgrd = function(theta,x) {
  th1 = theta[1]
  th2 = theta[2]
  eth1 = exp(th1)
  eth2 = exp(th2)
  expexp = eth1^eth2
  n = length(x)
  xeth2 = x^eth2 
  slogx = sum(log(x))
  sxeth2 = sum(xeth2)
  slxeth2 = sum(log(x)*xeth2)
  G1 = n*eth2 - eth2*expexp*sxeth2
  G2 = n*th1*eth2 + n + eth2*slogx - th1*eth2*expexp*sxeth2 - eth2*expexp*slxeth2 
  grdval = c(G1,G2)
  return(grdval)
}

#HESSIAN OF LOG-LIKELIHOOD FUNCTION
llhess = function(theta,x) {
  th1 = theta[1]
  th2 = theta[2]
  eth1 = exp(th1)
  eth2 = exp(th2)
  expexp = eth1^eth2
  n = length(x)
  xeth2 = x^eth2 
  slogx = sum(log(x))
  sxeth2 = sum(xeth2)
  slxeth2 = sum(log(x)*xeth2)
  sl2xeth2 = sum((log(x)^2)*xeth2)
  hess = matrix(0,2,2)
  hess[1,1] = -(eth2^2)*expexp*sxeth2 
  hess[1,2] = n*eth2 - eth2*expexp*sxeth2 - th1*(eth2^2)*expexp*sxeth2 -
    (eth2^2)*expexp*slxeth2
  hess[2,1] = hess[1,2]
  hess[2,2] = n*th1*eth2 + eth2*slogx - th1*eth2*expexp*sxeth2 - (th1^2)*(eth2^2)*expexp*sxeth2 -
    th1*(eth2^2)*expexp*slxeth2 - eth2*expexp*slxeth2 - th1*(eth2^2)*expexp*slxeth2 -
    (eth2^2)*expexp*sl2xeth2
  return(hess)
}

#SEARCH FOR STARTING VALUES
#WE HAD TO FIDDLE WITH THE SEARCH METHOD (trying different values of K and sig) 
#TO GET A GOOD STARTING VALUE
K = 50
sig = 1
cvals = rnorm(K,0,sig)
dvals = rnorm(K,0,sig)
lval = rep(0,K)
for (k in 1:K) {
  theta = c(cvals[k],dvals[k])
  lval[k] = llfun(theta,z)
}
k_opt = which.max(lval)
thtcur = c(cvals[k_opt],dvals[k_opt])

#SET UP FOR NEWTON-RAPHSON ITERATIONS
maxiter = 50
tol = 1e-6
diff = 99
iter = 0
rescur = c(0,thtcur)
rslts_mle = NULL

#CARRY OUT NEWTON-RAPHSON ITERATIONS
while ((iter < maxiter) & (diff > tol)) {
  grdval = llgrd(thtcur,z)
  rescur = c(rescur,grdval)
  rslts_mle = rbind(rslts_mle,rescur)
  iter = iter + 1
  hess = llhess(thtcur,z)
  step = solve(hess,grdval)
  thtcur = thtcur - step
  rescur = c(iter,thtcur)
  diff = max(abs(step))
}
grdval = llgrd(thtcur,z)
rescur = c(rescur,grdval)
rslts_mle = rbind(rslts_mle,rescur)
thtfin = thtcur

#PRINT RESULTS
rslts = as.data.frame(rslts_mle)
rownames(rslts_mle) = NULL
colnames(rslts_mle) = c('iter', 'th1', 'th2', 'g1', 'g2')
print(rslts_mle)
cat('\n')

#COVARIANCE MATRIX OF MLE = INVERSE INFORMATION MATRIX
vmat = -solve(llhess(thtfin,z)/n)

#WALD TEST ON theta_2
theta2null = log(1.5)
wald_stat = sqrt(n)*(thtfin[2] - theta2null)/sqrt(vmat[2,2])
wald_pvalue = 2*(1 - pnorm(wald_stat))
print(cbind(wald_stat,wald_pvalue))
cat('\n')

#LIKELIHOOD RATIO TEST ON theta_2
llmle = llfun(thtcur,z)
th1hat_null = -log(mean(z^1.5)) / 1.5
thnull = c(th1hat_null,theta2null)
llmle_null = llfun(thnull,z)
lr_stat = 2*(llmle - llmle_null)
lr_pvalue = 1 - pchisq(lr_stat,1)
print(cbind(lr_stat,lr_pvalue))
cat('\n')

