#PROGRAM TO COMPUTE MAXIMUM LIKELIHOOD ESTIMATES FOR THE BETA DISTRIBUTION
#AND CARRY OUT HYPOTHESIS TESTS

set.seed(5074283)
cat('\n')

#READ DATA
indat = read.table("ex10dat2.txt")
z = indat[,1]
n = length(z)

#LOG-LIKELIHOOD FUNCTION
llfun = function(theta,x) {
  mu = theta[1]
  tau = theta[2]
  n = length(x)
  alf = mu*tau
  bet = (1-mu)*tau
  llval = n*log(gamma(tau)) - n*log(gamma(alf)) - n*log(gamma(bet)) +
    (alf-1)*sum(log(x)) + (bet-1)*sum(log(1-x))
  return(llval)
}

#GRADIENT OF LOG-LIKELIHOOD FUNCTION
llgrd = function(theta,x) {
  mu = theta[1]
  tau = theta[2]
  n = length(x)
  alf = mu*tau
  bet = (1-mu)*tau
  mu.c = 1-mu
  xsum1 = sum(log(x))
  xsum2 = sum(log(1-x))
  G1 = -n*tau*digamma(alf) + n*tau*digamma(bet) + tau*(xsum1-xsum2)
  G2 = n*digamma(tau) - n*mu*digamma(alf) - n*mu.c*digamma(bet) + mu*xsum1 + mu.c*xsum2
  grdval = c(G1,G2)
  return(grdval)
}

#HESSIAN OF LOG-LIKELIHOOD FUNCTION
llhess = function(theta,x) {
  mu = theta[1]
  tau = theta[2]
  n = length(x)
  alf = mu*tau
  bet = (1-mu)*tau
  mu.c = 1-mu
  xsum = sum(log(x/(1-x)))
  hess = matrix(0,2,2)
  hess[1,1] = -n*(tau^2)*(trigamma(alf)+trigamma(bet))
  hess[1,2] = -n*digamma(alf) + n*digamma(bet) - n*alf*trigamma(alf) + n*bet*trigamma(bet) + xsum
  hess[2,1] = hess[1,2]
  hess[2,2] = n*trigamma(tau) - n*(mu^2)*trigamma(alf) - n*(mu.c^2)*trigamma(bet)
  return(hess)
}

#METHOD OF MOMENTS ESTIMATORS
mu.mom = mean(z)
tau.mom = (mu.mom*(1-mu.mom))/var(z) - 1
thtcur = c(mu.mom,tau.mom)

#SET UP FOR NEWTON-RAPHSON ITERATIONS
maxiter = 50
tol = 1e-6
diff = 99
iter = 0
rescur = c(0,thtcur)
rslts_mle = NULL

#CARRY OUT NEWTON-RAPHSON ITERATIONS
while ((iter < maxiter) & (diff > tol)) {
  grdval = llgrd(thtcur,z)
  rescur = c(rescur,grdval)
  rslts_mle = rbind(rslts_mle,rescur)
  iter = iter + 1
  hess = llhess(thtcur,z)
  step = solve(hess,grdval)
  thtcur = thtcur - step
  rescur = c(iter,thtcur)
  diff = max(abs(step))
}
grdval = llgrd(thtcur,z)
rescur = c(rescur,grdval)
rslts_mle = rbind(rslts_mle,rescur)
thtfin = thtcur

#PRINT RESULTS
rslts = as.data.frame(rslts_mle)
rownames(rslts_mle) = NULL
colnames(rslts_mle) = c('iter', 'th1', 'th2', 'g1', 'g2')
print(noquote('MLE results for full model'))
cat('\n')
print(rslts_mle)
cat('\n')

#COVARIANCE MATRIX OF MLE = INVERSE INFORMATION MATRIX
vmat = -solve(llhess(thtfin,z)/n)

#Wald statistic for testing the null hypothesis H_0: mu=0.35
theta1null = 0.35
wald_stat = sqrt(n)*(thtfin[1] - theta1null)/sqrt(vmat[1,1])
p_value_wald = 2*(1-pnorm(wald_stat))
print(noquote('Wald test of H_0: mu=0.35'))
cat('\n')
print(cbind(wald_stat,p_value_wald))
cat('\n')

#Likelihood ratio statistic for testing the null hypothesis H_0: mu=0.35

#SET UP FOR NEWTON-RAPHSON ITERATIONS
maxiter = 50
tol = 1e-6
diff = 99
iter = 0
taucur = thtfin[2]
rescur = c(0,taucur)
rslts_mle = NULL

#CARRY OUT NEWTON-RAPHSON ITERATIONS
while ((iter < maxiter) & (diff > tol)) {
  grdval = llgrd(c(theta1null,taucur),z)
  rescur = c(rescur,grdval[2])
  rslts_mle = rbind(rslts_mle,rescur)
  iter = iter + 1
  hess = llhess(c(theta1null,taucur),z)
  step = grdval[2]/hess[2,2]
  taucur = taucur - step
  rescur = c(iter,taucur)
  diff = max(abs(step))
}
grdval = llgrd(c(theta1null,taucur),z)
rescur = c(rescur,grdval[2])
rslts_mle = rbind(rslts_mle,rescur)
tau0fin = taucur

#PRINT RESULTS
rslts = as.data.frame(rslts_mle)
rownames(rslts_mle) = NULL
colnames(rslts_mle) = c('iter', 'tau', 'grad')
print(noquote('MLE results for H_0 model'))
cat('\n')
print(rslts_mle)
cat('\n')

#COMPUTE THE LIKELIHOOD RATIO STATISTIC
llmle = llfun(thtcur,z)
llmle_null = llfun(c(theta1null,tau0fin),z)
lr_stat = 2*(llmle - llmle_null)
lr_pvalue = 1 - pchisq(lr_stat,1)
print(noquote('Likelihood ratio test of H_0: mu=0.35'))
cat('\n')
print(cbind(llmle,llmle_null,lr_stat,lr_pvalue))
cat('\n')

#Wald statistic for testing the joint null hypothesis H_0: mu=0.35 and tau=4
difvec = c(thtfin[1]-0.35,thtfin[2]-4)
wald_stat = n * t(difvec) %*% solve(vmat) %*% difvec
wald_stat = as.vector(wald_stat)
p_value_wald = 1-pchisq(wald_stat,2)
print(noquote('Wald test for joint hypothesis'))
cat('\n')
print(cbind(wald_stat,p_value_wald))
cat('\n')


#Likelihood ratio statistic for testing the joint null hypothesis H_0: mu=0.35 and tau=4
llmle_null = llfun(c(0.35,4),z)
lr_stat = 2*(llmle - llmle_null)
lr_pvalue = 1 - pchisq(lr_stat,2)
print(noquote('Likelihood ratio test for joint hypothesis'))
cat('\n')
print(cbind(llmle,llmle_null,lr_stat,lr_pvalue))
cat('\n')

