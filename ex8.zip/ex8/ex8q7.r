#STATISTICS FOR DATA SCIENCE - EXERCISE SET 8, QUESTION 7

set.seed(5074283)

#FUNCTION FOR Kumaraswamy QUANTILE FUNCTION
fk_inv = function (u,a,b) x = (1 - (1-u)^(1/b))^(1/a)

#GENERATE THE SAMPLE FROM THE Kumaraswamy DISTRIBUTION WITH a=2 AND b=5
a = 2
b = 5
n = 500
u = runif(n)
z = fk_inv(u,a,b)

### METHOD OF MOMENTS ESTIMATION ##############################################

cat('\n')
print('Method of moments estimation')
cat('\n')

#G FUNCTION
Gfun = function(theta,x) {
  cval = theta[1]
  dval = theta[2]
  m1 = mean(x)
  m2 = mean(x^2)
  ecm = exp(-cval)
  ed = exp(dval)
  G1 = dval + log(gamma(1+ecm)) + log(gamma(ed)) - log(gamma(ecm+ed+1)) - log(m1)
  G2 = dval + log(gamma(1+2*ecm)) + log(gamma(ed)) - log(gamma(2*ecm+ed+1)) - log(m2) 
  Gval = c(G1,G2)
  return(Gval)
}

#JACOBIAN OF G                       
Gjac = function(theta) {
  cval = theta[1]
  dval = theta[2]
  jac = matrix(0,2,2)
  ecm = exp(-cval)
  ed = exp(dval)
  jac[1,1] = -ecm * (digamma(1+ecm) - digamma(ecm+ed+1))
  jac[1,2] = 1 + ed * (digamma(ed) - digamma(ecm+ed+1))
  jac[2,1] = -2*ecm * (digamma(1+2*ecm) - digamma(2*ecm+ed+1))
  jac[2,2] = 1 + ed * (digamma(ed) - digamma(2*ecm+ed+1))
  return(jac)
}

#SEARCH FOR STARTING VALUES
K = 10
sig = 2
cvals = rnorm(K,0,sig)
dvals = rnorm(K,0,sig)
gnrm2 = rep(0,K)
for (k in 1:K) {
  theta = c(cvals[k],dvals[k])
  Gval = Gfun(theta,z)
  gnrm2[k] = sum(Gval^2)
}
k_opt = which.min(gnrm2)
thtcur = c(cvals[k_opt],dvals[k_opt])

#SET UP FOR NEWTON-RAPHSON ITERATIONS
maxiter = 50
tol = 1e-6
diff = 99
iter = 0
rescur = c(0,thtcur)
rslts_mom = NULL

#CARRY OUT NEWTON-RAPHSON ITERATIONS
while ((iter < maxiter) & (diff > tol)) {
  Gval = Gfun(thtcur,z)
  rescur = c(rescur,Gval)
  rslts_mom = rbind(rslts_mom,rescur)
  iter = iter + 1
  jac = Gjac(thtcur)
  step = solve(jac,Gval)
  thtcur = thtcur - step
  rescur = c(iter,thtcur)
  diff = max(abs(step))
}
Gval = Gfun(thtcur,z)
rescur = c(rescur,Gval)
rslts_mom = rbind(rslts_mom,rescur)

#PRINT RESULTS
rslts = as.data.frame(rslts_mom)
rownames(rslts_mom) = NULL
colnames(rslts_mom) = c('iter', 'c', 'd', 'g1', 'g2')
print(rslts_mom)
cat('\n')

### MAXIMUM LIKELIHOOD ESTIMATION ##############################################

print('Maximum likelihood estimation')
cat('\n')
  
#LOG-LIKELIHOOD FUNCTION
llfun = function(theta,x) {
  cval = theta[1]
  dval = theta[2]
  ec = exp(cval)
  ed = exp(dval)
  xec = x^ec
  llval = n*(cval+dval) + (ec-1)*sum(log(x)) + (ed-1)*sum(log(1-xec))
  return(llval)
}

#GRADIENT OF LOG-LIKELIHOOD FUNCTION
llgrd = function(theta,x) {
  cval = theta[1]
  dval = theta[2]
  ec = exp(cval)
  ed = exp(dval)
  xec = x^ec
  G1 = n + ec*sum(log(x)) - (ed-1)*ec*sum(log(x)*xec/(1-xec))
  G2 = n + ed*sum(log(1-xec))
  grdval = c(G1,G2)
  return(grdval)
}

#HESSIAN OF LOG-LIKELIHOOD FUNCTION
llhess = function(theta,x) {
  cval = theta[1]
  dval = theta[2]
  ec = exp(cval)
  e2c = ec^2
  ed = exp(dval)
  xec = x^ec
  hess = matrix(0,2,2)
  hess[1,1] = ec*sum(log(x)) - (ed-1)*ec*sum(log(x)*xec/(1-xec)) -
    (ed-1)*e2c*sum((log(x)^2)*xec/(1-xec)) -
    (ed-1)*e2c*sum((log(x)^2)*xec/((1-xec)^2))
  hess[1,2] = -ec*ed*sum(log(x)*xec/(1-xec))
  hess[2,1] = hess[1,2]
  hess[2,2] = ed*sum(log(1-xec))
  return(hess)
}

#SEARCH FOR STARTING VALUES WITH SAME TEST POINTS AS BEFORE
#BUT NOW SEEKING THE POINT WITH THE HIGHEST LOG-LIKELHOOD
#IT TURNS OUT TO BE THE SAME POINT WE FOUND BEFORE
lval = rep(0,K)
for (k in 1:K) {
  theta = c(cvals[k],dvals[k])
  lval[k] = llfun(theta,z)
}
k_opt = which.max(lval)
thtcur = c(cvals[k_opt],dvals[k_opt])

#SET UP FOR NEWTON-RAPHSON ITERATIONS
maxiter = 50
tol = 1e-6
diff = 99
iter = 0
rescur = c(0,thtcur)
rslts_mle = NULL

#CARRY OUT NEWTON-RAPHSON ITERATIONS
while ((iter < maxiter) & (diff > tol)) {
  grdval = llgrd(thtcur,z)
  rescur = c(rescur,grdval)
  rslts_mle = rbind(rslts_mle,rescur)
  iter = iter + 1
  hess = llhess(thtcur,z)
  step = solve(hess,grdval)
  thtcur = thtcur - step
  rescur = c(iter,thtcur)
  diff = max(abs(step))
}
grdval = llgrd(thtcur,z)
rescur = c(rescur,grdval)
rslts_mle = rbind(rslts_mle,rescur)

#PRINT RESULTS
rslts = as.data.frame(rslts_mle)
rownames(rslts_mle) = NULL
colnames(rslts_mle) = c('iter', 'c', 'd', 'g1', 'g2')
print(rslts_mle)
cat('\n')





