#PROGRAM TO COMPUTE MAXIMUM LIKELIHOOD ESTIMATES FOR THE GAMMA DISTRIBUTION

#READ DATA
indat1 = read.table("ex8dat2.txt")
z = indat1[,1]
n = length(z)

#FUNCTION TO COMPUTE GRADIENT OF LOG-LIKELIHOOD
llgrad = function(theta,x) {
  alf = theta[1]
  bet = theta[2]
  n = length(x)
  s1 = sum(log(x))
  s2 = sum(x)
  d1a = -n*digamma(alf) - n*log(bet) + s1
  d1b = -(n*alf/bet) + s2/(bet^2)
  llgrad = c(d1a,d1b)
  return(llgrad)
 } 

#FUNCTION TO COMPUTE HESSIAN OF LOG-LIKELIHOOD  
llhess = function(theta,x) {
  alf = theta[1]
  bet = theta[2]
  n = length(x)
  smx = sum(x)
  hesmat = matrix(0,2,2)
  hesmat[1,1] = -n*trigamma(alf)
  hesmat[1,2] = -n/bet
  hesmat[2,1] = hesmat[1,2]
  hesmat[2,2] = n*alf/(bet^2) - 2*smx/(bet^3)
  return(hesmat)
}

#COMPUTE METHOD OF MOMENTS ESTIMATORS
meansam = mean(z)
vari = var(z)
alf_mom = (meansam^2)/vari
bet_mom = vari/meansam
thtcur = c(alf_mom,bet_mom)

#SET UP FOR NEWTON-RAPHSON ITERATIONS
maxiter = 50
tol = 1e-6
diff = 99
iter = 0
rescur = c(0,thtcur)
rslts = NULL

#CARRY OUT NEWTON-RAPHSON ITERATIONS
while ((iter < maxiter) & (diff > tol)) {
  grd = llgrad(thtcur,z)
  rescur = c(rescur,grd)
  rslts = rbind(rslts,rescur)
  iter = iter + 1
  hess = llhess(thtcur,z)
  step = solve(hess,grd)
  thtcur = thtcur - step
  rescur = c(iter,thtcur)
  diff = max(abs(step))
}
grd = llgrad(thtcur,z)
rescur = c(rescur,grd)
rslts = rbind(rslts,rescur)

#PRINT RESULTS
rslts = as.data.frame(rslts)
rownames(rslts) = NULL
colnames(rslts) = c('iter', 'alpha', 'beta', 'grad1', 'grad2')
print(rslts)
 