library(locpol)
indat = read.table("lp_ex_dat.txt")
x = indat[,1]
mx = indat[,2]
y = indat[,3]
datfrm = data.frame(x,y)
xmin = min(x)
xmax = max(x)
xrng = xmax - xmin
xval = xmin + xrng*c(0:500)/500
bwcv = regCVBwSelC(x, y, deg=1, kernel=gaussK)
lpl = locpol(y~x,data=datfrm,bw=bwcv,kernel=gaussK,deg=1,xeval=xval)
plot(x,y)
lines(x,mx,col='red')
lplfit = lpl$lpFit
lines(lplfit$x,lplfit$y,col='blue')
