#rule of thumb bandwidth selector in Fan & Gijbels Eqn. (4.3)
#for the case p=1, nu=0
#with w_0(x) = 1 for x between the 5th and 95th sample percentiles of the X's
#and w_0(x) = 0 otherwise

#C_{nu,p} for Epanechnikov kernel = 1.719
C.nu.p = 1.719

hrot = function(x,y) {
  #if p=1 then p+3=4
  x1 = x
  x2 = x^2
  x3 = x^3
  x4 = x^4
  reg = lm(y~x1+x2+x3+x4)
  alf = coef(reg)
  sig2 = summary(reg)$sigma^2
  q = quantile(x,c(0.05,0.95),type=8)
  rng = q[2]-q[1]
  w0 = (x >= q[1]) & (x <= q[2])
  denom0 = 2*alf[3] + 6*alf[4]*x + 12*alf[5]*(x^2)
  hrot = C.nu.p * ((sig2*rng/sum((denom0^2)*w0))^0.2)
  hrot = as.vector(hrot)
 } 
   

