#REGRESSION SPLINE DEMO

library(splines)

#GENERATE DATA
set.seed(57163)
x = seq(-2.5,2.5,by=0.125)
n = length(x)
ytru = 0.5*exp(x) + 1.0*sin(3*x)
y = ytru + rnorm(n,0,1)

#PLOT DATA
plot(x,y)
lines(x,ytru)

#CUBIC POLYNOMIAL FIT
u1 = x
u2 = x^2
u3 = x^3
a0 = lm(y~u1+u2+u3)
print(summary(a0))
ypred0 = a0$fitted.values
mse0 = sum((y-ypred0)^2)/(n-4)

lines(x,ypred0,col='green')

#CUBIC SPLINE FIT - TRUNCATED POWER BASIS - 4 INTERNAL KNOTS
knots1 = c(0:5) - 2.5
z1 = u1
z2 = u2
z3 = u3
zro = rep(0,41)
z4 = pmax(x-knots1[2],zro)^3
z5 = pmax(x-knots1[3],zro)^3
z6 = pmax(x-knots1[4],zro)^3
z7 = pmax(x-knots1[5],zro)^3
a1 = lm(y~z1+z2+z3+z4+z5+z6+z7)
print(summary(a1))
ypred1 = a1$fitted.values
lines(x,ypred1,col='red')

#CUBIC SPLINE FIT - B-SPLINE BASIS
knots = c(-4,-3.5,-3,knots1,3,3.5,4)
w = splineDesign(knots,x,ord=4)
w1 = w[,1]
w2 = w[,2]
w3 = w[,3]
w4 = w[,4]
w5 = w[,5]
w6 = w[,6]
w7 = w[,7]
w8 = w[,8]
a1a = lm(y~0+w1+w2+w3+w4+w5+w6+w7+w8)
print(summary(a1a))
ypred1a = a1a$fitted.values
print(summary(abs(ypred1-ypred1a)))

#CHOICE OF NUMBER OF KNOTS USING ADJUSTED R2
yvar = var(y)
df.vec = rep(0,10)
mse.vec = rep(0,10)
for (k in 1:10) {
  knots1 = seq(-2.5,2.5,length.out=k+2)
  knots = c(-4,-3.5,-3,knots1,3,3.5,4)
  xmat = splineDesign(knots,x,ord=4)
  df = ncol(xmat) - 1
  df.vec[k] = df
  beta = solve(t(xmat)%*%xmat,t(xmat)%*%y)
  pred = xmat %*% beta
  res = y-pred
  mse = sum(res^2)/(n-df-1)
  mse.vec[k] = mse
} 
df.vec = c(3,df.vec)
mse.vec = c(mse0,mse.vec)
sdvec = sqrt(mse.vec)
adj.R2 = 1 - mse.vec/yvar
nbreaks = 0:10
print(cbind(nbreaks,df.vec,sdvec,adj.R2))
plot(nbreaks,mse.vec,ylim=c(0,1.10*mse0))

#MODEL WITH 2 INTERIOR KNOTS
knots1 = seq(-2.5,2.5,length.out=4)
zro = rep(0,41)
v1 = pmax(x-knots1[2],zro)^3
v2 = pmax(x-knots1[3],zro)^3
a2 = lm(y~z1+z2+z3+v1+v2)
print(summary(a2))
ypred2 = a2$fitted.values

#PLOT DATA, TRUE CURVE, AND ESTIMATED CURVES
plot(x,y)
lines(x,ytru)
lines(x,ypred0,col='green')
lines(x,ypred1,col='red')
lines(x,ypred2,col='blue')
  


#EXAMPLE PLOT OF B-SPLINE
plot(x,w4,type='l')
lines(x,w6)



