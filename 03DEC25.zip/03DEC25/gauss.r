#SETUPS
library(statmod)
k = 10

#GET GAUSSIAN NODES AND WEIGHTS FOR INTEGRATION W.R.T. exp(-u^2)
gh = gauss.quad(k,kind="hermite")
nodes = gh$nodes
weights = gh$weights

#ADJUST NODES AND WEIGHTS AS NEEDED FOR INTEGRATION W.R.T. exp(-v^2/2)/sqrt(2*pi)
nodes = sqrt(2) * nodes
weights = weights/sqrt(pi)

#DEMO
power = rep(0,k)
moment = rep(0,k)
for (r in 1:k) {
  pow = 2*r-1
  power[r] = pow
  moment[r] = sum(weights*(nodes^pow))
 }
results1 = cbind(power,moment)
moment = rep(0,k-1)
power = rep(0,k-1)
for (r in 1:(k-1)) {
  pow = 2*r
  power[r] = pow
  moment[r] = sum(weights*(nodes^pow))
 }
results2 = cbind(power,moment)
print("odd moments - should all be zero") 
print(results1)
print("even moments") 
print(results2)
