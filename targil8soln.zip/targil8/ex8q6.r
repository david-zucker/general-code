#EXERCISE SET 8, QUESTION 6

#PRELIMINARIES
set.seed(342345)
za = -qnorm(0.025)
n = 200
p_tru = 0.8
lam_tru = 4
B = 1000

#FUNCTION TO GENERATE DATA FROM THE ZIP DISTRIBUTION
rzip = function(n,p,lam) {
  u = rbinom(n,1,p)
  y = rpois(n,lam)
  z = ifelse(u==1,y,0)
}  

#NORMALIZED LOG-LIKELIHOOD FUNCTION
#normalized by dividing by n
llik = function(theta,x) {
  eth1 = exp(theta[1])
  eth2 = exp(theta[2])
  expexp = exp(-eth2)
  pval = eth1/(eth1+1)
  qq = 1 + eth1*expexp
  expr1 = -log(eth1+1) + log(qq)
  expr2 = theta[1] - log(eth1+1) + theta[2]*x - log(factorial(x)) - eth2
  ww = ifelse(x==0,expr1,expr2)
  llval = mean(ww)
  return(llval)
}  
  
#GRADIENT OF NORMALIZED LOG-LIKELIHOOD FUNCTION  
llgrd = function(theta,x) {
  eth1 = exp(theta[1])
  eth2 = exp(theta[2])
  expexp = exp(-eth2)
  pval = eth1/(eth1+1)
  qq = 1 + eth1*expexp
  wd1expr1 = -pval + eth1*expexp/qq
  wd2expr1 = -(eth1*eth2*expexp/qq)
  wd1expr2 = 1 - pval
  wd2expr2 = x - eth2
  G1 = mean(ifelse(x==0,wd1expr1,wd1expr2))
  G2 = mean(ifelse(x==0,wd2expr1,wd2expr2))
  grd = c(G1,G2)
  return(grd)
}  

#EXPECTED HESSIAN OF LOG DENSITY  
ellhess = function(theta,x) {
  eth1 = exp(theta[1])
  eth2 = exp(theta[2])
  expexp = exp(-eth2)
  pval = eth1/(eth1+1)
  qq = 1 + eth1*expexp
  qq2 = qq^2
  b = eth1*expexp/qq
  pq = pval*(1-pval)
  prb0 = (1-pval) + pval*expexp
  prb1 = 1 - prb0
  ehess = matrix(0,2,2)
  wdd11expr1 = -pq + b*(1-b)
  wdd11expr2 = -pq
  ehess[1,1] = prb0*wdd11expr1 + prb1*wdd11expr2
  wdd12expr1 = -(eth1*eth2*expexp/qq) + ((eth1^2)*eth2*exp(-2*eth2))/(qq2)
  ehess[1,2] = prb0*wdd12expr1
  ehess[2,1] = ehess[1,2]
  wdd22expr1 = eth1*eth2*expexp*(eth2-1)/qq - (eth1*eth2*expexp/qq)^2
  ehess[2,2] = prb0*wdd22expr1 + prb1*(-eth2)
  return(ehess)
}  

#FUNCTION TO OBTAIN THE MLE'S FOR THE ZIP DISTRIBUTION  
zipmle = function(x) {  

  #METHOD OF MOMENTS ESTIMATES OF THE PARAMETERS
  m1 = mean(x)
  m2 = mean(x^2)
  mfrac = m2/m1
  lam_mm = mfrac - 1
  p_mm = m1/lam_mm
  th1_mm = log(p_mm/(1-p_mm))
  th2_mm = log(lam_mm)  
  thtcur = c(th1_mm,th2_mm)
  
  #SET UP FOR FISHER SCORING ITERATIONS
  maxiter = 50
  tol = 1e-6
  diff = 99
  iter = 0

  #CARRY OUT FISHER SCORING ITERATIONS
  while ((iter < maxiter) & (diff > tol)) {
    grdval = llgrd(thtcur,x)
    iter = iter + 1
    ehess = ellhess(thtcur,x)
    step = solve(ehess,grdval)
    thtcur = thtcur - step
    diff = max(abs(step))
  }
  grdval = llgrd(thtcur,x)
  
  #RETURN ANSWER
  ans = c(thtcur,grdval)
  ans = as.data.frame(t(ans))
  rownames(ans) = NULL
  colnames(ans) = c('theta_1', 'theta_2', 'grad_1', 'grad_2')
  return(ans)

}  
  
### MAIN PROGRAM ###

#GENERATE SAMPLE OF SIZE n FROM ZIP(p_tru,lam_tru) DISTRIBUTION
x_orig = rzip(n,p_tru,lam_tru)
  
#COMPUTE ESTIMATES OF THETA FROM THE ORIGINAL DATA 
est_orig = zipmle(x_orig)   
cat('\n')
print(noquote('Estimates of theta from the original data'))
cat('\n')
print(est_orig)
th1_orig = est_orig$theta_1
th2_orig = est_orig$theta_2
th_orig = c(th1_orig,th2_orig)

#ESTIMATE mu AND omega
omega_hat = th1_orig - log(1+exp(th1_orig)) + th2_orig
mu_hat = exp(omega_hat)
cat('\n')
print(noquote('Estimates of omega and mu from the original data'))
cat('\n')
print(cbind(omega_hat,mu_hat))
cat('\n')

#METHOD A: ASYMPTOTIC CI WITH ASYMPTOTIC VARIANCE
vmat = -solve(ellhess(th_orig))
phat_orig = exp(th1_orig)/(exp(th1_orig)+1)
grd_omg = matrix(c(1-phat_orig,1),2,1)
asyvar = t(grd_omg) %*% vmat %*% grd_omg  / n
cihw1 = za*sqrt(asyvar)
omega_lo_1 = omega_hat - cihw1
omega_hi_1 = omega_hat + cihw1

#PARAMETRIC BOOTSTRAP REPLICATIONS
lamhat_orig = exp(th2_orig)
tstar = rep(0,B)
for (b in 1:B) {
  xcur = rzip(n,phat_orig,lamhat_orig)
  estcur = zipmle(xcur)
  th1cur = estcur$theta_1
  th2cur = estcur$theta_2
  omega_cur = th1cur - log(exp(th1cur)+1) + th2cur
  tstar[b] = omega_cur - omega_hat
 }

#METHOD B: ASYMPTOTIC CI WITH PARAMETRIC BOOTSTRAP VARIANCE
cihw2 = za*sd(tstar)
omega_lo_2 = omega_hat - cihw2
omega_hi_2 = omega_hat + cihw2

#METHOD C: PARAMETRIC BOOSTRAP CI
qnt = quantile(tstar,c(0.975,0.025),type=8)
omega_lo_3 = omega_hat - qnt[1]
omega_hi_3 = omega_hat - qnt[2]

#NONPARAMETRIC BOOTSTRAP REPLICATIONS
tstar = rep(0,B)
for (b in 1:B) {
  xcur = sample(x_orig,n,replace=TRUE)
  estcur = zipmle(xcur)
  th1cur = estcur$theta_1
  th2cur = estcur$theta_2
  omega_cur = th1cur - log(exp(th1cur)+1) + th2cur
  tstar[b] = omega_cur - omega_hat
}

#METHOD D: NONPARAMETRIC BOOSTRAP CI
qnt = quantile(tstar,c(0.975,0.025),type=8)
omega_lo_4 = omega_hat - qnt[1]
omega_hi_4 = omega_hat - qnt[2]

#SUMMARIZE RESULTS
rslt_omega = rbind(
  c(omega_lo_1,omega_hi_1),
  c(omega_lo_2,omega_hi_2),
  c(omega_lo_3,omega_hi_3),
  c(omega_lo_4,omega_hi_4))
rslt_omega = as.data.frame(rslt_omega)
colnames(rslt_omega) = c('omega_lo','omega_hi')
rownames(rslt_omega) = c('Method A', 'Method B', 'Method C', 'Method D')
rslt_mu = exp(rslt_omega)
colnames(rslt_mu) = c('mu_lo','mu_hi')
rownames(rslt_mu) = c('Method A', 'Method B', 'Method C', 'Method D')

#PRINT RESULTS
print(noquote('Confidence intervals for omega'))
cat('\n')
print(rslt_omega)
cat('\n')
print(noquote('Confidence intervals for mu'))
cat('\n')
print(rslt_mu)
cat('\n')