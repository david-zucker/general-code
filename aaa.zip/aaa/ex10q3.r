

alf = 0.025
zcrit = qnorm(1-alf)
mu = seq(-1,2.2,0.02)
power10 = pnorm(sqrt(10)*mu-zcrit)
power20 = pnorm(sqrt(20)*mu-zcrit)
power30 = pnorm(sqrt(30)*mu-zcrit)
plot(mu,power10,type='l', col='blue')
lines(mu,power20,col='green')
lines(mu,power30,col='red')
lines(c(-1,2),c(0.025,0.025))



