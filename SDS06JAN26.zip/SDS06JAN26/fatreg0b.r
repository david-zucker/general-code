indat = read.table("fatdat.txt")
names(indat) = c('id', 'fatbro', 'fatsir', 'density', 'age', 'wt', 'ht', 
  'BMI', 'ffw', 'neck', 'chest', 'abdo','hip', 'thigh', 'knee', 'ankle', 
  'biceps', 'forearm', 'wrist')

#the y variable is fatbro: percent body fat using Brozek's method
#we will use the following x variables: age, adip, chest, abdo, hip, thigh)

#BMI = wt.kg/(ht.m^2)

reg = lm(fatbro ~  abdo + age, data=indat)
print(summary(reg))

 