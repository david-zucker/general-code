# LOGISTIC REGRESSION

# READ THE DATA
indat = read.csv("mrfit.csv",header=T,sep=",")
attach(indat)
# These are data on a sample of 5305 men from a follow-up study on risk factors for heart disease.
# The explantory variables are as follows:
#   age = age in years
#   diab = 0/1 indicator for presence (1) or absence (0) of diabetes
#   chol = cholesterol level
#   map = mean arterial blood pressure [= (2/3)*(diastolic BP) + (1/3)*(systolic BP)
#   smoke = 0/1 indicator for whether the person smokes (1) or does not smoke (0)
# The outcome variable died10 is a 0/1 of whether the person died during the first 10 years of follow-up (died10=1)
#    or survived the entire 10 years (died10=0)

#RUN LOGISTIC REGRESSION
lr1 = glm(died10 ~ age + diab + chol + map + smoke, family=binomial(link=logit))
print(summary(lr1))
print(vcov(lr1))

