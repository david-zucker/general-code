library(MASS)
library(bestglm)
options(width=200)

# read the data
# % body weight from fat as a function of the BMI and various body measurements
indat = read.table("fatdat.txt")
names(indat) = c('id', 'fatbro', 'fatsir', 'density', 'age', 'wt', 'ht', 
  'BMI', 'ffw', 'neck', 'chest', 'abdo','hip', 'thigh', 'knee', 'ankle', 
  'biceps', 'forearm', 'wrist')

# specify min and max models 
frmla = 'fatbro ~ age + BMI + chest + abdo + hip + thigh'
reg.min = lm(fatbro ~ BMI, data=indat)
reg.full = lm(frmla, data=indat)

#variable selection using stepAIC

#output of stepAIC:
#Sum of Sq = change in SSE caused by adding/deleting the variable to the model
#RSS = SSE after the variable is added/deleted

#forward (k is what we called kappa in class. k=2 gives AIC)
reg.fw = stepAIC(reg.min, scope=list(lower=formula(reg.min), 
  upper=formula(reg.full)), direction='forward', k=2)
summary(reg.fw)

#backwards
reg.bw = stepAIC(reg.full, scope=list(lower=formula(reg.min), 
  upper=formula(reg.full)), direction='backward', k=2)
summary(reg.bw)

#stepwise
reg.bth = stepAIC(reg.min, scope=list(lower=formula(reg.min), 
  upper=formula(reg.full)), direction='both', k=2)
summary(reg.bth)

#best subsets regression using regsubsets
#bestglm does not allow forcing variables into the model
pmax = 6
M = 20
Xy = indat[, c('age', 'BMI', 'neck', 'chest', 'abdo','hip', 'thigh',
  'knee', 'ankle', 'biceps', 'forearm', 'wrist', 'fatbro')]
reg.best.a = bestglm(Xy, family=gaussian, IC='AIC',nvmax=pmax,TopModels=M)
reg.best.a$BestModels
reg.best.a$Subsets
print(reg.best.a)

nvmax1 = pmax+1
rsubs.a = reg.best.a$Subsets
aic = rsubs.a$AIC
aic.diff = aic[1] - aic[2:nvmax1] 
aic.pct.diff = aic.diff/aic.diff[pmax]
rsubs.a$aic.diff = c(0,aic.diff)
rsubs.a$aic.pct.diff = c(0,aic.pct.diff)
rsubs.a

pmax=2
reg.best.b = bestglm(Xy, family=gaussian, IC='AIC',nvmax=pmax,TopModels=M)
reg.best.b$BestModels
reg.best.b$Subsets
print(reg.best.b)
nvmax1 = pmax+1
rsubs.b = reg.best.b$Subsets
aic = rsubs.b$AIC
aic.diff = aic[1] - aic[2:nvmax1] 
aic.pct.diff = aic.diff/aic.diff[pmax]
rsubs.b$aic.diff = c(0,aic.diff)
rsubs.b$aic.pct.diff = c(0,aic.pct.diff)
rsubs.b

#models with abdo substantially better than those without
#looks like approaximately equally good fits are obtained with abdo and either wrist, neck, or hip

