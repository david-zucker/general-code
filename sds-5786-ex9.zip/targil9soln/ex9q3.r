#POWER FOR GIVEN n, alpha, AND mu
pwr = function(n,alf,mu) {
  zcrit = qnorm(1-alf)
  pwr = pnorm(sqrt(n)*mu-zcrit)
  return(pwr)
}

power10 = pwr(10,0.025,mu)
power20 = pwr(20,0.025,mu)
power30 = pwr(30,0.025,mu)
plot(mu,power10,type='l', col='blue')
lines(mu,power20,col='green')
lines(mu,power30,col='red')
lines(c(-1,2),c(0.025,0.025))

#SAMPLE SIZE NEEDED FOR GIVEN alpha, mu, and POWER LEVEL
samsiz = function(alf,pwr,mu) {
  za = qnorm(1-alf)
  zb = qnorm(pwr)
  n = (za+zb)^2/mu^2
  return(n)
} 

n = samsiz(0.025,0.90,0.75)
print(n)
lines(c(0.75,0.75),c(0,1))
lines(c(-1,2),c(0.90,0.90))
